// Shared by the content script and the popup — the one place a default lives.
// One row per colour token: CSS variable, popup label, default value.
const FD_COLORS = [
  ['--fd-accent', 'Accent', '#17c8f4'],
  ['--fd-accent-hi', 'Accent bright', '#6fdcff'],
  ['--fd-accent-soft', 'Accent tint', '#082f49'],
  ['--fd-accent-ink', 'Text on accent', '#04121f'],
  ['--fd-surface', 'Surface', '#0d1b2e'],
  ['--fd-surface-2', 'Ground', '#060d18'],
  ['--fd-ink', 'Text', '#e8f2fa'],
  ['--fd-ink-muted', 'Muted text', '#8fa8c0'],
  ['--fd-ink-faint', 'Faint text', '#5c7189'],
  ['--fd-line', 'Line', '#16283f'],
  ['--fd-line-strong', 'Strong line', '#24405f'],
  ['--fd-ok', 'Success', '#34d399'],
  ['--fd-warn', 'Warning', '#fbbf24'],
  ['--fd-err', 'Error', '#f87171'],
];

const FD_DEFAULTS = {
  enabled: true,
  colors: Object.fromEntries(FD_COLORS.map(([v, , d]) => [v, d])),
  motion: { enter: true, hover: true, transitions: true },
  footer: true,
};

// Stored settings are partial (older versions, a token added later): fill from defaults.
const FD_MERGE = (raw = {}) => ({
  enabled: raw.enabled ?? FD_DEFAULTS.enabled,
  colors: { ...FD_DEFAULTS.colors, ...(raw.colors || {}) },
  motion: { ...FD_DEFAULTS.motion, ...(raw.motion || {}) },
  footer: raw.footer ?? FD_DEFAULTS.footer,
});
