// Frost for Blackboard Ultra — content script, document_start.
// Three jobs: (1) put frost.css on the page while the theme is on (a <link> we own, so the popup
// can toggle it without a reload), (2) push settings onto <html> — custom --fd-* colours as inline
// vars, which beat the stylesheet defaults, and the motion/footer switches as data attributes,
// (3) the long tail: tag what no selector can reach and let frost.css restyle the tag.
(() => {
  if (window.__fdFrost) return;
  window.__fdFrost = true;

  const html = document.documentElement;
  const SKIP = /^(IMG|VIDEO|CANVAS|SVG|IFRAME|PICTURE|SOURCE|PATH|USE|SCRIPT|STYLE|LINK|META)$/;
  const TAGS = ['data-fd-light', 'data-fd-dark', 'data-fd-fixed-bottom', 'data-fd-vh'];
  let settings = FD_DEFAULTS;
  let link = null;
  let observer = null;
  let timer = 0;

  // Luminance of an rgb()/rgba() string; null when transparent, or when the colour is saturated
  // (an accent button, a grade pill) — only greys and whites are Ultra's "paper", never brand colours.
  const lum = (c) => {
    const m = c.match(/[\d.]+/g);
    if (!m || (m[3] !== undefined && +m[3] < 0.5)) return null;
    if (Math.max(m[0], m[1], m[2]) - Math.min(m[0], m[1], m[2]) > 60) return null;
    return (0.2126 * m[0] + 0.7152 * m[1] + 0.0722 * m[2]) / 255;
  };
  const hexLum = (h) => { const n = parseInt(h.slice(1), 16); return (0.2126 * (n >> 16) + 0.7152 * ((n >> 8) & 255) + 0.0722 * (n & 255)) / 255; };
  const hasText = (e) => { for (const n of e.childNodes) if (n.nodeType === 3 && n.textContent.trim()) return true; return false; };
  const onBody = (fn) => (document.body ? fn() : document.addEventListener('DOMContentLoaded', fn, { once: true }));

  // ---- long tail -------------------------------------------------------------------------------
  // Read everything first, write after: setting an attribute mid-loop invalidates layout and the
  // next getBoundingClientRect would force a reflow, once per element.
  const sweep = () => {
    const pending = [];
    for (const e of document.body.querySelectorAll('*')) {
      if (SKIP.test(e.tagName) || e.id === 'fd-footer' || e.closest('svg')) continue;
      const cs = getComputedStyle(e);
      const tags = [];
      const bg = lum(cs.backgroundColor);
      if (bg !== null && bg > 0.4 && cs.backgroundImage === 'none') tags.push('data-fd-light');
      const fg = lum(cs.color);
      if (fg !== null && fg < 0.35 && hasText(e)) tags.push('data-fd-dark');
      const r = e.getBoundingClientRect();
      // Fixed to the bottom of the VIEWPORT (Ultra's action bars, the help button): outside the
      // shrunk layout, so it would sit over the footer. Lift it by the footer height.
      if (cs.position === 'fixed' && r.bottom >= innerHeight - 1) tags.push('data-fd-fixed-bottom');
      // Sized with 100vh (Ultra's route containers): the shrunk wrappers can't reach it, so clamp.
      if (Math.abs(r.height - innerHeight) <= 1) tags.push('data-fd-vh');
      if (tags.length) pending.push([e, tags]);
    }
    for (const [e, tags] of pending) for (const a of tags) e.setAttribute(a, '');
  };
  const schedule = () => { clearTimeout(timer); timer = setTimeout(sweep, 150); };
  const startSweep = () => {
    if (observer) return;
    sweep();
    observer = new MutationObserver(schedule);
    observer.observe(document.body, { childList: true, subtree: true, attributes: true, attributeFilter: ['class', 'style'] });
  };
  const stopSweep = () => {
    observer?.disconnect();
    observer = null;
    clearTimeout(timer);
    for (const a of TAGS) for (const e of document.querySelectorAll(`[${a}]`)) e.removeAttribute(a);
  };

  // ---- footer ---------------------------------------------------------------------------------
  // A full-width bar, top frame only. frost.css shrinks the app by --fd-footer-h so the bar sits
  // below everything rather than over it.
  const syncFooter = () => {
    const want = link && settings.footer && window.top === window && document.body;
    const have = document.getElementById('fd-footer');
    if (want && !have) {
      const f = document.createElement('footer');
      f.id = 'fd-footer';
      const a = document.createElement('a');
      a.href = 'https://frostdev.io';
      a.target = '_blank';
      a.rel = 'noopener';
      a.textContent = '❄ Frosted by frostdev.io';
      f.appendChild(a);
      document.body.appendChild(f);
    } else if (!want && have) have.remove();
  };

  // ---- settings → <html> ----------------------------------------------------------------------
  const applySettings = () => {
    for (const [v] of FD_COLORS) html.style.setProperty(v, settings.colors[v]);
    html.style.colorScheme = hexLum(settings.colors['--fd-surface']) > 0.5 ? 'light' : 'dark';
    html.toggleAttribute('data-fd-no-trans', !settings.motion.transitions);
    html.toggleAttribute('data-fd-no-enter', !settings.motion.enter);
    html.toggleAttribute('data-fd-no-hover', !settings.motion.hover);
    html.toggleAttribute('data-fd-footer', settings.footer);
    syncFooter();
  };
  const clearSettings = () => {
    for (const [v] of FD_COLORS) html.style.removeProperty(v);
    html.style.removeProperty('color-scheme');
    for (const a of ['data-fd-no-trans', 'data-fd-no-enter', 'data-fd-no-hover', 'data-fd-footer']) html.removeAttribute(a);
  };

  const enable = () => {
    if (!link) {
      link = document.createElement('link');
      link.rel = 'stylesheet';
      link.href = chrome.runtime.getURL('frost.css');
      (document.head || html).appendChild(link);
    }
    applySettings();
    onBody(() => { if (link) { syncFooter(); startSweep(); } });
  };
  const disable = () => {
    link?.remove();
    link = null;
    stopSweep();
    clearSettings();
    syncFooter();
  };

  const load = () => new Promise((res) => chrome.storage.sync.get(null, (raw) => res(FD_MERGE(raw))));
  load().then((s) => { settings = s; if (s.enabled) enable(); });
  chrome.storage.onChanged.addListener((_, area) => {
    if (area !== 'sync') return;
    load().then((s) => {
      const was = settings.enabled && !!link;
      settings = s;
      if (s.enabled && !was) enable();
      else if (!s.enabled && was) disable();
      else if (s.enabled) applySettings();
    });
  });
})();
