// Popup: every control writes straight to chrome.storage.sync; the content script listens.
const $ = (s) => document.querySelector(s);
let settings = FD_MERGE();

// Switches save at once: the popup closes the moment focus leaves it, and a pending timer dies
// with it. Colour inputs fire on every drag tick and sync storage has a per-minute write quota,
// so those alone are debounced.
let saveTimer = 0;
const save = () => { clearTimeout(saveTimer); chrome.storage.sync.set(settings); };
const saveSoon = () => { clearTimeout(saveTimer); saveTimer = setTimeout(save, 150); };

// The popup previews the palette on itself.
const preview = () => { for (const [v] of FD_COLORS) document.documentElement.style.setProperty(v, settings.colors[v]); };

const render = () => {
  $('#enabled').checked = settings.enabled;
  document.body.classList.toggle('off', !settings.enabled);
  const grid = $('#colors');
  grid.replaceChildren();
  for (const [v, label] of FD_COLORS) {
    const row = document.createElement('label');
    const input = Object.assign(document.createElement('input'), { type: 'color', value: settings.colors[v], title: v });
    input.addEventListener('input', () => { settings.colors[v] = input.value; preview(); saveSoon(); });
    input.addEventListener('change', save);
    row.append(input, label);
    grid.append(row);
  }
  for (const cb of document.querySelectorAll('[data-motion]')) cb.checked = settings.motion[cb.dataset.motion];
  $('#footer').checked = settings.footer;
  preview();
};

chrome.storage.sync.get(null, (raw) => { settings = FD_MERGE(raw); render(); });

$('#enabled').addEventListener('change', (e) => {
  settings.enabled = e.target.checked;
  document.body.classList.toggle('off', !settings.enabled);
  save();
});
for (const cb of document.querySelectorAll('[data-motion]')) {
  cb.addEventListener('change', () => { settings.motion[cb.dataset.motion] = cb.checked; save(); });
}
$('#footer').addEventListener('change', (e) => { settings.footer = e.target.checked; save(); });
$('#reset').addEventListener('click', () => { settings.colors = { ...FD_DEFAULTS.colors }; render(); save(); });
